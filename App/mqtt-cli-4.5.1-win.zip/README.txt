To execute MQTT CLI simply open the Windows Command Prompt with ⊞Win + R and execute cmd.
Navigate into the extracted MQTT CLI folder and execute the mqtt-cli.exe command.

To quick start a MQTT CLI shell simply double-click the mqtt-cli-shell.cmd file.